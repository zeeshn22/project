package com.examly.springapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.UserExistException;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.UserRepo;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepo userRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public User createUser(User user) {
        System.out.println("User -> " + user);
        User existUser = userRepo.findByUsername(user.getUsername());
        if (existUser != null) {
            throw new UserExistException("User with same name exists");
        }
        user.setUsername(user.getUsername());
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepo.save(user);
    }

    public User findByUserName(String username) {
        return userRepo.findByUsername(username);
    }

    public User loginUser(User user) {
        User foundUser = userRepo.findByUsername(user.getUsername());
        if (foundUser != null) {
            User existingUser = foundUser;
            if (user.getPassword().equals(existingUser.getPassword())) {
                return existingUser;
            }
        }
        return null;
    }

}


package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import java.util.List;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.exceptions.DuplicateBookException;
import com.examly.springapp.model.BookRentalRequest;
import com.examly.springapp.service.BookRentalRequestService;

@RestController
@CrossOrigin(allowedHeaders = "https://8081-cddadcdbcadaaaaeafedbaeeacbaba.premiumproject.examly.io", methods = {
        RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE })
public class BookRentalRequestController {

    @Autowired
    BookRentalRequestService brrService;

    @GetMapping("/api/bookrentalrequest/admin")
    public ResponseEntity<BookRentalRequest> getByRequestId(@PathVariable long id) {
        BookRentalRequest b = brrService.getBookRentalRequestById(id);
        System.out.println("bbbbbbbbbbbbbbbbbb");
        if (b != null) {
            return new ResponseEntity<>(b, HttpStatus.OK);

        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/api/bookrentalrequest/admin")
    public ResponseEntity<?> update(@RequestBody BookRentalRequest b, @PathVariable long id) {
        b = brrService.updateBookRentalRequest(id, b);
        System.out.println("bbbbbbbbbbbbbbbbbb");
        if (b != null) {
            return new ResponseEntity<>(b, HttpStatus.OK);

        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/api/bookrentalrequest/{id}")
    public ResponseEntity<?> delete(@PathVariable long id) {
        boolean b = brrService.deleteBookRentalRequest(id);
        if (b) {
            return new ResponseEntity<>(b, HttpStatus.OK);

        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PostMapping("/api/bookrentalrequest")
    public ResponseEntity<?> add(@RequestBody BookRentalRequest request) {

        try {
            request = brrService.addBookRentalRequest(request);
            System.out.println("bbbbbbbbbbbbbbbbbb");
            if (request != null)
                return new ResponseEntity<>(request, HttpStatus.CREATED);
            else
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (DuplicateBookException dbe) {
            return new ResponseEntity<>(dbe.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/api/bookrentalrequest")
    public ResponseEntity<List<BookRentalRequest>> getAll() {
        List<BookRentalRequest> list = brrService.getAllBookRentalRequests();
        if (list.size() > 0)
            return new ResponseEntity<>(list, HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/api/bookrentalrequest/user/{userId}")
    public ResponseEntity<List<BookRentalRequest>> getById(@PathVariable int userId) {
        List<BookRentalRequest> list = brrService.getBookRentalRequestsByUserId(userId);
        if (list.size() > 0)
            return new ResponseEntity<>(list, HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

}

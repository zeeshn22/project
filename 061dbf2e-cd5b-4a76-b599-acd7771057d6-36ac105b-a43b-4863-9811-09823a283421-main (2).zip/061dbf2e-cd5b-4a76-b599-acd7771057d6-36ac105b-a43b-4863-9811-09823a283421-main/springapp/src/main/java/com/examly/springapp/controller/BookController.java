package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Book;
import com.examly.springapp.service.BookService;

@RestController
@CrossOrigin(allowedHeaders = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE })
public class BookController {

    @Autowired
    private BookService bookService;

    @PostMapping("/api/addbook")
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        Book b = bookService.addBook(book);
        if (b != null) {
            return ResponseEntity.status(200).body(b);
        } else {
            return ResponseEntity.status(400).build();
        }
    }

    @GetMapping("/api/viewbooks")
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> b = bookService.getAllBooks();
        if (b.isEmpty()) {
            return ResponseEntity.status(400).build();

        } else {
            return ResponseEntity.status(200).body(b);
        }
    }

    @GetMapping("/api/books/{bookId}")
    public ResponseEntity<Book> getBookById(@PathVariable Long bookId) {
        Book b = bookService.getBookById(bookId);
        if (b != null) {
            return ResponseEntity.status(200).body(b);

        } else {
            return ResponseEntity.status(400).build();
        }
    }

    @PutMapping("/api/viewbooks/{bookId}")
    public ResponseEntity<Book> updateBook(@PathVariable Long bookId, @RequestBody Book book) {
        Book b = bookService.updateBook(bookId, book);
        if (b != null) {
            return ResponseEntity.status(200).body(b);
        } else {
            return ResponseEntity.status(404).build();
        }
    }

    @DeleteMapping("/api/viewbooks/{bookId}")
    public ResponseEntity<?> deleteBook(@PathVariable Long bookId) {
        if (bookService.deleteBook(bookId)) {
            return ResponseEntity.status(200).body(true);
        } else {
            return ResponseEntity.status(404).body(false);
        }
    }
}

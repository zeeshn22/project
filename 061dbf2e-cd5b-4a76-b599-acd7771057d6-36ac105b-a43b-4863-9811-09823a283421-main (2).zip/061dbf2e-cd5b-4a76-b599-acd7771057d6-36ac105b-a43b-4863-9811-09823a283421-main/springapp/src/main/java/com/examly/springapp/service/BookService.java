package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.model.Book;

public interface BookService {

    public Book addBook(Book book);

    public Book getBookById(Long bookId);

    public List<Book> getAllBooks();

    public Book updateBook(Long bookId, Book updateBook);

    public Boolean deleteBook(long bookId);

}

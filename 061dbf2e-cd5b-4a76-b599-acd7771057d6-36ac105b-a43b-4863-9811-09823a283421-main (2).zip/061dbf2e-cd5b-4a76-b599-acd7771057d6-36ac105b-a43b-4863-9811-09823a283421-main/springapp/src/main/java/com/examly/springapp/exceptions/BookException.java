package com.examly.springapp.exceptions;

public class BookException extends RuntimeException{
    public BookException(String msg){
        super(msg);
    }
}

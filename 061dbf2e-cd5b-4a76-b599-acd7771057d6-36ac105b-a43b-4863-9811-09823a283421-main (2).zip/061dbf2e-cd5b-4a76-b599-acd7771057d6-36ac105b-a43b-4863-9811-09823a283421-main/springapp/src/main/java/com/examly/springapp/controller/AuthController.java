package com.examly.springapp.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.config.JwtUtils;
import com.examly.springapp.exceptions.UserExistException;
import com.examly.springapp.model.ResponseDTO;
import com.examly.springapp.model.User;
import com.examly.springapp.service.UserService;

@RestController
@CrossOrigin(allowedHeaders = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE })
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private JwtUtils jwtService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @PostMapping("/api/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        try {
            System.out.println("************Register : " + user);
            userService.createUser(user);
            return ResponseEntity.status(HttpStatus.CREATED).body(true);
        } catch (UserExistException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
        }

    }

    @PostMapping("/api/login")
    public ResponseDTO authenticateAndGetToken(@RequestBody User user) {

        Authentication authentication = authenticationManager
                .authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword()));
        if (authentication.isAuthenticated()) {
            User loginUser = userService.findByUserName(user.getUsername());
            System.out.println("User -> " + loginUser);
            ResponseDTO dto = new ResponseDTO();
            dto.setId(loginUser.getUserId());
            dto.setToken(jwtService.GenerateToken(user.getUsername()));
            dto.setUserRole(loginUser.getUserRole());
            return dto;
        } else {
            throw new UsernameNotFoundException("invalid user request..!!");
        }
    }

}

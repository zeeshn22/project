
package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.model.BookRentalRequest;

public interface BookRentalRequestService {

    BookRentalRequest getBookRentalRequestById(long requestId);

    BookRentalRequest updateBookRentalRequest(long requestId, BookRentalRequest request);

    boolean deleteBookRentalRequest(long requestId);

    BookRentalRequest addBookRentalRequest(BookRentalRequest request);

    List<BookRentalRequest> getAllBookRentalRequests();

    List<BookRentalRequest> getBookRentalRequestsByUserId(int userId);

}


package com.examly.springapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.DuplicateBookException;
import com.examly.springapp.model.BookRentalRequest;
import com.examly.springapp.repository.BookRentalRequestRepo;
import com.examly.springapp.repository.BookRepo;
import com.examly.springapp.repository.UserRepo;

@Service
public class BookRentalRequestServiceImpl implements BookRentalRequestService {

    @Autowired
    BookRentalRequestRepo brrRepo;

    @Autowired
    BookRepo brepo;

    @Autowired
    UserRepo urepo;

    @Override
    public BookRentalRequest getBookRentalRequestById(long requestId) {
        return brrRepo.findById(requestId).get();
    }

    @Override
    public BookRentalRequest updateBookRentalRequest(long requestId, BookRentalRequest request) {
        if (brrRepo.existsById(requestId)) {
            request.setRentalId(requestId);
            return brrRepo.save(request);
        }
        return null;
    }

    @Override
    public boolean deleteBookRentalRequest(long requestId) {
        if (brrRepo.existsById(requestId)) {
            brrRepo.deleteById(requestId);
            return true;
        }
        return false;

    }

    public BookRentalRequest addBookRentalRequest(BookRentalRequest request) {

        List<BookRentalRequest> arr = brrRepo.getUserId(request.getUser().getUserId());
        if (arr.isEmpty()) {
            return brrRepo.save(request);
        } else {
            for (BookRentalRequest b : arr) {
                if (b.getBook().getBookId() == request.getBook().getBookId()) {
                    throw new DuplicateBookException();
                }
            }
        }
        return brrRepo.save(request);

    }

    @Override
    public List<BookRentalRequest> getAllBookRentalRequests() {
        return brrRepo.findAll();
    }

    @Override
    public List<BookRentalRequest> getBookRentalRequestsByUserId(int userId) {
        return brrRepo.getUserId(userId);
    }

}

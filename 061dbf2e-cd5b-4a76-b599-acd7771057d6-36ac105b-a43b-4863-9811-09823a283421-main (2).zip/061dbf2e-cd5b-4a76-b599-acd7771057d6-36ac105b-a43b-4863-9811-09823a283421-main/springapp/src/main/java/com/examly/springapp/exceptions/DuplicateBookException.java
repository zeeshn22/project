package com.examly.springapp.exceptions;

public class DuplicateBookException {
    
}

package com.examly.springapp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.examly.springapp.model.ResponseDTO;

@Configuration
public class ResponseDTOConfig {

    @Bean
    public ResponseDTO responseDTO() {
        return new ResponseDTO();
    }

}

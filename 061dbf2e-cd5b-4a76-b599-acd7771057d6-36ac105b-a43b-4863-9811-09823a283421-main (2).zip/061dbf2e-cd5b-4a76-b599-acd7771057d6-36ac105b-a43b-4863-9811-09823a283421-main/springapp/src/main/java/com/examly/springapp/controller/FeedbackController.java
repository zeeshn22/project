package com.examly.springapp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.Feedback;
import com.examly.springapp.service.FeedbackServiceImpl;

@RestController
@CrossOrigin(allowedHeaders = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE })
public class FeedbackController {

    @Autowired
    private FeedbackServiceImpl feedbackService;

    @PostMapping("/api/userfeedback")
    public ResponseEntity<?> addFeedback(@RequestBody Feedback feedback) {
        try {
            Feedback createdFeedback = feedbackService.addFeedback(feedback);
            return ResponseEntity.status(201).body(createdFeedback);
        } catch (UserNotFoundException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    @GetMapping("/api/feedback/user/{userId}")
    public ResponseEntity<?> getFeedbackByUser(@PathVariable int userId) {
        try {
            List<Feedback> feedbacks = feedbackService.getFeedbackByUserld(userId);
            return ResponseEntity.status(200).body(feedbacks);
        } catch (UserNotFoundException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    @DeleteMapping("/api/feedback/{id}")
    public ResponseEntity<?> deleteFeedback(@PathVariable int id) {
        try {
            Feedback deletedFeedback = feedbackService.deleteFeedback(id);
            return ResponseEntity.status(200).body(deletedFeedback);
        } catch (RuntimeException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    @GetMapping("/api/feedback/getall")
    public ResponseEntity<?> getAllFeedbacks() {
        try {
            List<Feedback> feedbacks = feedbackService.getAllFeedbacks();
            return ResponseEntity.status(200).body(feedbacks);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    @GetMapping("/api/feedback/{id}")
    public ResponseEntity<?> getFeedbackById(@PathVariable int id) {
        try {
            Optional<Feedback> feedback = feedbackService.getFeedbackById(id);
            if (feedback == null) {
                return ResponseEntity.status(404).body("Feedback not found with ID: " + id);
            } else {
                return ResponseEntity.status(200).body(feedback);
            }
        } catch (Exception e) {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    @PutMapping("/api/feedback/update/{id}")
    public ResponseEntity<?> updateFeedback(@PathVariable int id, @RequestBody Feedback updatedFeedback) {
        try {
            Feedback feedback = feedbackService.updateFeedback(id, updatedFeedback);
            if (feedback != null) {
                return ResponseEntity.status(200).body(feedback);
            } else {
                return ResponseEntity.status(404).body("Feedback not found with ID: " + id);
            }
        } catch (RuntimeException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }
}

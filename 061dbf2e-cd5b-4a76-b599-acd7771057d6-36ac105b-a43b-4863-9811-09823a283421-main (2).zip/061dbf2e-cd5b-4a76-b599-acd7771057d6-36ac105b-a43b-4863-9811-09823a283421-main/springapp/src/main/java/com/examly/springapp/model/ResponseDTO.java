package com.examly.springapp.model;

public class ResponseDTO {
    String token;
    int id;
    String userRole;

    @Override
    public String toString() {
        return "ResponseDTO [token=" + token + ", id=" + id + ", userRole=" + userRole + "]";
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserRole() {
        return userRole;
    }

    public void setUserRole(String userRole) {
        this.userRole = userRole;
    }

    public ResponseDTO() {
    }

    public ResponseDTO(String token, int id, String userRole) {
        this.token = token;
        this.id = id;
        this.userRole = userRole;

    }

}


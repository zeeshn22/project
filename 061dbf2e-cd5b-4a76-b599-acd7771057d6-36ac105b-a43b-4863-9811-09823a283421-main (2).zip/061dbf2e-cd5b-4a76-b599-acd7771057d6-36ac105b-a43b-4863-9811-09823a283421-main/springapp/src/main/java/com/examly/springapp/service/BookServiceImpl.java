package com.examly.springapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Book;
import com.examly.springapp.repository.BookRepo;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    private BookRepo bookRepo;

    public Book addBook(Book book) {
        if (book.getCoverImage() != null && !book.getCoverImage().isEmpty()) {
            return bookRepo.save(book);
        }
        return null;
    }

    public Book getBookById(Long bookId) {
        if (bookRepo.existsById(bookId)) {
            return bookRepo.findById(bookId).get();
        }
        return null;
    }

    public List<Book> getAllBooks() {
        return bookRepo.findAll();
    }

    public Book updateBook(Long bookId, Book updateBook) {
        if (bookRepo.existsById(bookId)) {
            Book book = bookRepo.findById(bookId).get();
            book.setTitle(updateBook.getTitle());
            book.setAuthor(updateBook.getAuthor());
            book.setGenre(updateBook.getGenre());
            book.setDescription(updateBook.getDescription());
            book.setRentalFee(updateBook.getRentalFee());
            book.setIsAvailable(updateBook.getIsAvailable());
            book.setCoverImage(updateBook.getCoverImage());
            book = bookRepo.save(updateBook);
            return book;
        } else {
            return null;
        }
    }

    public Boolean deleteBook(long bookId) {
        if (bookRepo.existsById(bookId)) {
            bookRepo.deleteById(bookId);
            return true;
        }
        return false;
    }

}

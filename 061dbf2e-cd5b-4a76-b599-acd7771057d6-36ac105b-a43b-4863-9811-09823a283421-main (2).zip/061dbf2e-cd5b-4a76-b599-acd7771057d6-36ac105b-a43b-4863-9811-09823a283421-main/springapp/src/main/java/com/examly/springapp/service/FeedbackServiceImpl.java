package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.Feedback;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.FeedbackRepo;
import com.examly.springapp.repository.UserRepo;

@Service
public class FeedbackServiceImpl implements FeedbackService {

    @Autowired
    private FeedbackRepo feedbackRepo;

    @Autowired
    private UserRepo userRepo;

    @Override
    public Feedback addFeedback(Feedback feedback) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        User user = userRepo.findByUsername(username);
        if (user == null) {
            new UserNotFoundException("User not found with username: " + username);
        }
        feedback.setUser(user);
        return feedbackRepo.save(feedback);
    }

    @Override
    public List<Feedback> getFeedbackByUserld(int userId) {
        return feedbackRepo.findByUserId(userId);
    }

    @Override
    public List<Feedback> getAllFeedbacks() {
        return feedbackRepo.findAll();
    }

    @Override
    public Optional<Feedback> getFeedbackById(int id) {
        return feedbackRepo.findById(id);
    }

    @Override
    public Feedback updateFeedback(int id, Feedback updatedFeedback) {
        Feedback feedback = feedbackRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Feedback not found with ID: " + id));
        feedback.setFeedbackText(updatedFeedback.getFeedbackText());
        feedback.setDate(updatedFeedback.getDate());
        return feedbackRepo.save(feedback);
    }

    @Override
    public Feedback deleteFeedback(int id) {
        Feedback feedback = feedbackRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Feedback not found with ID: " + id));
        feedbackRepo.delete(feedback);
        return feedback;
    }
}

package com.examly.springapp.exceptions;

public class FeedbackExistsException extends RuntimeException{
    public FeedbackExistsException(String msg){
        super(msg);
    }
}

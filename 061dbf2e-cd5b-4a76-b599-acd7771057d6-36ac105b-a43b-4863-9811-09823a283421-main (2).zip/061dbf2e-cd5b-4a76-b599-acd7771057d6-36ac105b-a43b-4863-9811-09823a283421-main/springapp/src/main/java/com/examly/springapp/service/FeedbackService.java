package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import com.examly.springapp.model.Feedback;

public interface FeedbackService {

    public List<Feedback> getFeedbackByUserld(int userId);

    public List<Feedback> getAllFeedbacks();

    public Optional<Feedback> getFeedbackById(int id);

    public Feedback addFeedback(Feedback feedback);

    public Feedback updateFeedback(int id, Feedback updateFeedback);

    public Feedback deleteFeedback(int id);
}

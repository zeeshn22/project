
import { SignupComponent } from './components/signup/signup.component';
import { AdminnavComponent } from './components/adminnav/adminnav.component';

import { AdminbookComponent } from './components/adminbook/adminbook.component';
import { AdminviewbookComponent } from './components/adminviewbook/adminviewbook.component';



import { UserviewfeedbackComponent } from './components/userviewfeedback/userviewfeedback.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import { UseraddrequestComponent } from './components/useraddrequest/useraddrequest.component';
import { AdminviewfeedbackComponent } from './components/adminviewfeedback/adminviewfeedback.component';
import { UserAddFeedbackComponent } from './components/useraddfeedback/useraddfeedback.component';
import { RouteGuardService } from './services/route-guard.service';
import { AuthgaurdComponent } from './components/authgaurd/authgaurd.component';


import { AdminViewAppliedRequestComponent } from './components/adminviewappliedrequest/adminviewappliedrequest.component';
import { UserViewAppliedRequestComponent } from './components/userviewappliedrequest/userviewappliedrequest.component';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { UsernavComponent } from './components/usernav/usernav.component';
import { UserviewbooksComponent } from './components/userviewbooks/userviewbooks.component';
import { NgModule } from '@angular/core';
import { ErrorComponent } from './components/error/error.component';

const routes: Routes = [
  { path: '',component: LoginComponent },
  { path: 'api/register', component: SignupComponent },
  { path: 'api/login', component: LoginComponent },
  { path: 'admin', component:AdminnavComponent, canActivate:[RouteGuardService]},
  { path: 'user', component: UsernavComponent, canActivate:[RouteGuardService]},
  {path: 'api/addbook', component: AdminbookComponent, canActivate:[RouteGuardService]},
  {path: 'api/viewbook',component: AdminviewbookComponent, canActivate:[RouteGuardService]},
  {path: 'api/bookrentalrequest/admin',component: AdminViewAppliedRequestComponent, canActivate:[RouteGuardService]},
  {path:'api/feedback',component: UserviewfeedbackComponent, canActivate:[RouteGuardService]},
  {path:'api/viewbooks',component: UserviewbooksComponent, canActivate:[RouteGuardService]},
  {path:'api/viewbookrentalrequest',component: UserViewAppliedRequestComponent, canActivate:[RouteGuardService]},
  {path:'api/userfeedback',component: UserAddFeedbackComponent, canActivate:[RouteGuardService]},
  {path: 'api/home', component: HomePageComponent, canActivate:[RouteGuardService]},
  {path:'api/adminfeedback', component:AdminviewfeedbackComponent, canActivate:[RouteGuardService]},
  {path:'api/bookrentalrequest/:id', component:UseraddrequestComponent, canActivate:[RouteGuardService]},
  {path:'unauthorized', component:ErrorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchP'
})
export class SearchPPipe implements PipeTransform {

  transform(array:any[], searchTerm:string): any[] {
    
    if(!searchTerm || !array)
      return array;

    array = array.filter(data=>
      JSON.stringify(data).toLowerCase().includes(searchTerm.toLocaleLowerCase()));
      return array;
  }
}

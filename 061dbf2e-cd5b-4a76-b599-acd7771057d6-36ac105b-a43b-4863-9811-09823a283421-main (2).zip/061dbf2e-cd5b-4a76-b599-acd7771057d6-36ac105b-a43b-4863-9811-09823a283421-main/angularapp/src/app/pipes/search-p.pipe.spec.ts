import { SearchPPipe } from './search-p.pipe';

describe('SearchPPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchPPipe();
    expect(pipe).toBeTruthy();
  });
});

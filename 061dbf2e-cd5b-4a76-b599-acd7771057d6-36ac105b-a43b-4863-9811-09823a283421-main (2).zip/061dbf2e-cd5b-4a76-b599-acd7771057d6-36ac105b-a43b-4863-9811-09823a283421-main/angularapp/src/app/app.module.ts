import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { AdminnavComponent } from './components/adminnav/adminnav.component';

import { AdminviewbookComponent } from './components/adminviewbook/adminviewbook.component';
import { AdminviewfeedbackComponent } from './components/adminviewfeedback/adminviewfeedback.component';
import { AuthgaurdComponent } from './components/authgaurd/authgaurd.component';
import { ErrorComponent } from './components/error/error.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { UserAddFeedbackComponent } from './components/useraddfeedback/useraddfeedback.component';
import { UseraddrequestComponent } from './components/useraddrequest/useraddrequest.component';
import { UsernavComponent } from './components/usernav/usernav.component';

import { UserviewbooksComponent } from './components/userviewbooks/userviewbooks.component';
import { UserviewfeedbackComponent } from './components/userviewfeedback/userviewfeedback.component';
import { AdminbookComponent } from './components/adminbook/adminbook.component';

import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import { UserViewAppliedRequestComponent } from './components/userviewappliedrequest/userviewappliedrequest.component';
import { SearchBookPipe } from './pipes/search-book.pipe';
import { SearchRequestsPipe } from './pipes/search-request.pipe';
import { AdminViewAppliedRequestComponent } from './components/adminviewappliedrequest/adminviewappliedrequest.component';
import { HttpInterceptorBasicAuthService } from './services/http-intercepter-basic-auth.service';


@NgModule({
  declarations: [
    AppComponent,
    AdminbookComponent,
    AdminnavComponent,
    AdminViewAppliedRequestComponent,
    AdminviewbookComponent,
    AdminviewfeedbackComponent,
    AuthgaurdComponent,
    ErrorComponent,
    HomePageComponent,
    LoginComponent,
    SignupComponent,
    UseraddrequestComponent,
    UsernavComponent,
    UserViewAppliedRequestComponent,
    UserviewbooksComponent,
    UserviewfeedbackComponent,
    UserAddFeedbackComponent,
    SearchBookPipe,
    SearchRequestsPipe

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,

    FormsModule,

    ReactiveFormsModule

  ],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorBasicAuthService, multi: true }],
  bootstrap: [AppComponent]
})
export class AppModule { }

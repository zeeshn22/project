import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';

import { catchError, map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { User } from '../models/user.model';
export const AUTHENTICATED_USER = 'authenticatedUser';
 
export class AuthenticationBean {
  constructor(
    public id: number,
    public token: string,
    public userRole:string) { }
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  apiUrl = environment.apiUrl;

  constructor(private HttpClient: HttpClient) { }

  executeAuthencationService(username: string, password: string): Observable<AuthenticationBean> {
    return this.HttpClient.post<AuthenticationBean>(`${this.apiUrl}api/login`, { username, password }).pipe(
      map(data => {
          console.log("Data from backend -> " + data)
          sessionStorage.setItem(AUTHENTICATED_USER, 'true');
          sessionStorage.setItem("USER_ID", data.id.toString());
          sessionStorage.setItem("USER_USERNAME", username);
          sessionStorage.setItem("USER_ROLE", data.userRole);
          sessionStorage.setItem("TOKEN", `Bearer ${data.token}`);
          return data;
        }
      ),
      catchError(this.handleError)
    );
  }
  executeRegisterService(user: User): Observable<any> {
    return this.HttpClient.post<User>(`${this.apiUrl}api/register`, user).pipe(
      map(data => {
        return data;
      }),
      catchError(this.handleError)
      );
    }
 
 
  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'Unknown error!'; if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Error: ${error.error.message}`; } else {
        // Server-side error
        errorMessage = error.error || 'Server error'; }
        return throwError(errorMessage);
      }
 
  getAuthenticatedUserId(): number {
    return parseInt(sessionStorage.getItem("USER_ID"));
  }
 
  getAuthenticatedUsername() {
    return sessionStorage.getItem("USER_USERNAME");
  }
 
  getAuthenticatedUserRole() {
    return sessionStorage.getItem("USER_ROLE");
  }
 
  getAuthenticatedToken() {
    if (this.getAuthenticatedUsername())
      return sessionStorage.getItem("TOKEN");
  }
 
  isUserLoggedIn() {
    let user = sessionStorage.getItem(AUTHENTICATED_USER);
    return !(user == null);
  }
 
  logout() {
    sessionStorage.clear();
    console.log("Cleared session storage !!");
  }

  
  

}

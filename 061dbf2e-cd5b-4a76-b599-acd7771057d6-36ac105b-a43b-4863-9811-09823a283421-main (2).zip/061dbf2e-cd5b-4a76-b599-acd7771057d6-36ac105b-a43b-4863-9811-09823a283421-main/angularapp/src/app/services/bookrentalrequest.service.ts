import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BookRentalRequest } from '../models/book-rental-request.model';

@Injectable({
  providedIn: 'root'
})
export class BookrentalrequestService {
  apiUrl = "https://8080-cddadcdbcadaaaaeafedbaeeacbaba.premiumproject.examly.io";

  constructor(private http:HttpClient) {}

  getAllBookRentalRequests():Observable<any[]>{
    console.log("called3")
    return this.http.get<any[]>(this.apiUrl+'/api/bookrentalrequest');
  }

  getBookRentalRequestByUserId(userId:number):Observable<any>{
    return this.http.get<any>(this.apiUrl+'/api/bookrentalrequest/user/'+userId);
  }

  getBookRentalRequestById(rentalId:number):Observable<any>{
    console.log("called1")
    return this.http.get<any>(this.apiUrl+'/api/bookrentalrequest/admin/'+rentalId);
  }

  addBookRentalRequest(request:BookRentalRequest):Observable<any>{
    let ob = {
      user: {
        userId: request.id,
      },
      book: {
        bookId: request.bookId,
      },
      requestDate: request.requestDate,
      returnDate: request.returnDate,
      status: request.status,
      comments: request.comments,
      reason: request.reason
    };
    return this.http.post<any>(this.apiUrl+'/api/bookrentalrequest',ob);
  }

  updateBookRentalRequest(rentalId:number, request:Partial<BookRentalRequest>):Observable<any>{
    console.log("called")
    return this.http.put<any>(this.apiUrl+'/api/bookrentalrequest/admin/'+rentalId, request);
    
  }

  deleteBookRentalRequest(rentalId:number):Observable<any>{
    return this.http.delete<any>(this.apiUrl+'/api/bookrentalrequest/'+rentalId);
  }
}

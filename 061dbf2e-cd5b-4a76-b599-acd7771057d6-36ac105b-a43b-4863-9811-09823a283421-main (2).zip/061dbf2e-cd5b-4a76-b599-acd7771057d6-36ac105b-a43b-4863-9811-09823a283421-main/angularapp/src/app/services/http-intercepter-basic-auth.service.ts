
import { HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable, ɵpatchComponentDefWithScope } from '@angular/core';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})

export class HttpInterceptorBasicAuthService implements HttpInterceptor {

  constructor(private authService: AuthService) { }

  intercept(request: HttpRequest<any>, next: HttpHandler) {
    const token = this.authService.getAuthenticatedToken();
    const id = this.authService.getAuthenticatedUserId();
    console.log("userid.. "+id)
    console.log(token)
    if (token) {
      request = request.clone({
        setHeaders: {
          Authorization: token
        }
      });
    }
    return next.handle(request);
  }
}

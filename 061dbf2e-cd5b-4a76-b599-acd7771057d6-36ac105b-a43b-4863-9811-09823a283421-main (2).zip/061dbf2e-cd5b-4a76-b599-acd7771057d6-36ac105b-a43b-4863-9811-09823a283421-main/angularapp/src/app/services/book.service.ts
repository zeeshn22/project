import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Book } from "../models/book.model";

@Injectable({
  providedIn: 'root'
})
export class BookService {


  public apiUrl: string = "https://8080-cddadcdbcadaaaaeafedbaeeacbaba.premiumproject.examly.io/api";
  constructor(private httpClient:HttpClient) { }

  getAllBooks():Observable<Book[]>{
    return this.httpClient.get<Book[]>(this.apiUrl+'/viewbooks');
  }
  getBookById(bookId: number):Observable<any>{
    return this.httpClient.get(this.apiUrl+"/"+bookId);
  }

  addBook(book:Book):Observable<any>{
    return this.httpClient.post(this.apiUrl+'/addbook', book);
  }

  updateBook(bookId: number,book:Book):Observable<any>{
    return this.httpClient.put(this.apiUrl+"/viewbooks/"+bookId, book);
  }

  deleteBook(bookId:number):Observable<any>{
    return this.httpClient.delete(this.apiUrl+"/viewbooks/"+bookId);
  }
}

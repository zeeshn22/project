import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { BookService } from 'src/app/services/book.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-adminbook',
  templateUrl: './adminbook.component.html',
  styleUrls: ['./adminbook.component.css']
})
export class AdminbookComponent implements OnInit {

  bookForm: FormGroup
  showLogoutConfirm = false;
  selectedImage: string = '';
  constructor(private service: BookService, private builder: FormBuilder, private authService: AuthService, private route: Router) { }

  ngOnInit(): void {
    this.bookForm = this.builder.group({
      title: ['', [Validators.required]],
      author: ['', [Validators.required]],
      genre: ['', [Validators.required]],
      description: ['', [Validators.required]],
      rentalFee: ['', [Validators.required, Validators.min(20)]],
      coverImage: [null]
    });
  }

  get f() {
    return this.bookForm.controls;
  }



  addBook() {
    let obj = {
      title: this.bookForm.value.title,
      author: this.bookForm.value.author,
      genre: this.bookForm.value.genre,
      description: this.bookForm.value.description,
      rentalFee: this.bookForm.value.rentalFee,
      quantity: this.bookForm.value.quantity,
      available: this.bookForm.value.available,
      coverImage: this.bookForm.value.coverImage
    }
    console.log("object created");

    this.service.addBook(this.bookForm.value).subscribe(() => {
      console.log("Data added successfully!!")
      Swal.fire({
        icon: 'success',
        title: 'Book Added!',
        text: 'Your new book has been successfully added to the library!',
        showClass: {
          popup: 'animated bounceIn'
        },
        hideClass: {
          popup: 'animated bounceOut'
        },
        background: '#ffe0b2',  // Light Orange background
        color: '#7b1fa2',  // Purple text
        confirmButtonColor: '#f57c00',  // Deep Orange button
        confirmButtonText: 'Yay!'
      });
      this.bookForm.reset();
      // this.router.navigate(['/viewBooks']);
    }, (error) => {
      console.log('from boot....' + error);
      alert("Book already exists");
    });
  }

  logout(): void {
    this.authService.logout();
    this.route.navigate(['/api/login']);
  }

  confirmLogout(): void {
    this.showLogoutConfirm = true;
  }

  cancelLogout(): void {
    this.showLogoutConfirm = false;
  }

  performLogout(): void {
    this.showLogoutConfirm = false;
    this.logout();
  }

  onImageSelected(event: Event): void {

    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();

      reader.onload = () => {
        this.selectedImage = reader.result as string;
        this.bookForm.patchValue({ coverImage: this.selectedImage });
      };
      reader.readAsDataURL(file);
    }
  }
}

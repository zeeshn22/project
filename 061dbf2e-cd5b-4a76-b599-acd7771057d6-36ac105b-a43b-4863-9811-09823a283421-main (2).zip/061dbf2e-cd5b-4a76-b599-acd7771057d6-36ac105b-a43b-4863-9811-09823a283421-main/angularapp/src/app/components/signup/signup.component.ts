import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
 
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
 
  signupForm: FormGroup;
  showSignup: boolean = false;
  user: any = {};
  loading: boolean = false;
  signupError: string = '';
 
  constructor(private fb: FormBuilder , private authService:AuthService,private router:Router) { }
 
  ngOnInit(): void {
 
    this.signupForm = this.fb.group({
      username: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$")]],
      mobileNumber: ['', [Validators.required, Validators.pattern("^[6-9][0-9]{9}$")]],
      password: ['', [Validators.required,Validators.pattern("/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/")]],
      confirmPassword: ['', Validators.required],
      userRole: ['', Validators.required]
    }, { validators: passwordMatchValidator('password', 'confirmPassword') });
  }


  public get signup() {
    return this.signupForm.controls;
  }

  registerUser() {
    if (this.signupForm.valid) {
      this.loading = true; // Show the loader
      this.user = this.signupForm.value;
      
      this.authService.executeRegisterService(this.user).subscribe(
        (data) => {
          this.loading = false; // Hide the loader
          console.log("Registration successful");
          this.showSignup = !this.showSignup;
          this.router.navigate["/api/login"];
        },
        (error) => {
          this.loading = false; // Hide the loader on error
          if (error === 'User with same name exists') {
            this.signupError = 'Username already exists. Please choose another one.';
          } if (error === 'Email already exists') {
            this.signupError = 'Email already exists. Please use a different email address.'
          }else {
            this.signupError = 'Registration failed. Please try again.';
          }
          console.error("Registration failed: ", error);
        }
      );
    }
  }
}
 
function passwordMatchValidator(password: string, confirmPassword: string): ValidatorFn {
  return (formGroup: AbstractControl): ValidationErrors | null => {
    const passwordControl = formGroup.get(password);
    const confirmPasswordControl = formGroup.get(confirmPassword);
 
    if (!passwordControl || !confirmPasswordControl) {
      return null;
    }
 
    const passwordsMatch = passwordControl.value === confirmPasswordControl.value;
 
    return passwordsMatch ? null : { passwordsMismatch: true };
  };
}






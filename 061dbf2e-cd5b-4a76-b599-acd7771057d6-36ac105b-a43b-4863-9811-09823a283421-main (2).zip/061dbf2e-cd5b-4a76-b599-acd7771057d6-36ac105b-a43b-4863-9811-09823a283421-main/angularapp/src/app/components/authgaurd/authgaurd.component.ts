import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-authgaurd',
  templateUrl: './authgaurd.component.html',
  styleUrls: ['./authgaurd.component.css']
})
export class AuthgaurdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

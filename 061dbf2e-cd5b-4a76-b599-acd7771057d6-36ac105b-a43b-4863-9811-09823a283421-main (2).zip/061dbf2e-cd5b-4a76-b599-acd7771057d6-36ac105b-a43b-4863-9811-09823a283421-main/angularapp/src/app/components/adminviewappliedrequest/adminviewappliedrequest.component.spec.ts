import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminViewAppliedRequestComponent } from './adminviewappliedrequest.component';

describe('AdminviewappliedrequestComponent', () => {
  let component: AdminViewAppliedRequestComponent;
  let fixture: ComponentFixture<AdminViewAppliedRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminViewAppliedRequestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminViewAppliedRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

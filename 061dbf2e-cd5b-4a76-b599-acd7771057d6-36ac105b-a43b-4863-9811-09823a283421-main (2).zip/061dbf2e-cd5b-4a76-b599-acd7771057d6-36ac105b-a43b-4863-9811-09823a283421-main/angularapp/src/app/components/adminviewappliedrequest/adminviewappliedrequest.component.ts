import { Component, OnInit } from '@angular/core';
import { Feedback } from 'src/app/models/feedback.model';
import { BookService } from 'src/app/services/book.service';
import { BookrentalrequestService } from 'src/app/services/bookrentalrequest.service';

@Component({
  selector: 'app-adminviewappliedrequest',
  templateUrl: './adminviewappliedrequest.component.html',
  styleUrls: ['./adminviewappliedrequest.component.css']
})
export class AdminViewAppliedRequestComponent implements OnInit {
  rentalRequests: any[] = [];
  filteredRequests: any[] = [];
  filterStatus: string = 'All';
  searchQuery: string = '';
  rejectRequest: any = null;
  setRequest:any;
  requestId: number;

  feedback: Feedback[];
  constructor(private bookRentalService: BookrentalrequestService,private bookService:BookService) {}

  ngOnInit(): void {
    
    // this.filteredRequests = [...this.rentalRequests];
    this.getRentalRequests();
  }

  filterRequests(): void {
    this.filteredRequests = this.rentalRequests.filter(request => {
      const matchesStatus = this.filterStatus === 'All' || request.status === this.filterStatus;
      const matchesSearchQuery = request.username.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
                                 request.bookTitle.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
                                 request.author.toLowerCase().includes(this.searchQuery.toLowerCase());
      return matchesStatus && matchesSearchQuery;
    });
  }

  getRentalRequests(){
    this.bookRentalService.getAllBookRentalRequests().subscribe(data=>{
      this.rentalRequests=data;
    })
  }

  approveRequest(id: number): void {
    const request = this.rentalRequests.find((req) => req.id === id);
    if (request) {
      request.status = 'Approved';
      // this.filterRequests();
    }
  }

  rejectRequestById(id: number): void {
    const request = this.rentalRequests.find((req) => req.id === id);
    if (request) {
        request.status = 'Rejected';
      // this.filterRequests();
    }
  }

  // approveRequest(id: number): void {
  //   this.bookRentalService.getBookRentalRequestById(id).subscribe(data=>{
  //     this.setRequest=data;
  //     this.setRequest.status="Approved";
  //     const book = this.setRequest.book;
  //     this.bookService.updateBook(book.bookId!, book).subscribe(() => {
  //       console.log("Book quantity updated successfully!!");

  //       this.bookRentalService.updateBookRentalRequest(id, this.setRequest).subscribe(() => {
  //         this.getRentalRequests();
  //       });
  //     });
  //   })
  // }

  // rejectRequestById(id: number): void{
  //   this.requestId = id;
    
  //   this.bookRentalService.getBookRentalRequestById(id).subscribe(data => {
  //     console.log("rentalId"+this.requestId)
  //     this.setRequest = data;
  //     this.setRequest.status = "Rejected";
  //   });
  // }

  showDetails(request: any): void {
    this.rejectRequest = request; 
  }

  closeModal(): void {
    this.rejectRequest = null; 
  }
}

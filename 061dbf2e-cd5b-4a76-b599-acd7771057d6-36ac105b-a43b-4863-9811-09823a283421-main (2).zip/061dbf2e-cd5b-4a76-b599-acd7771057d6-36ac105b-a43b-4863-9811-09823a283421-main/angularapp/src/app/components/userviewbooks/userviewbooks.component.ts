import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BookRentalRequest } from 'src/app/models/book-rental-request.model';
import { Book } from 'src/app/models/book.model';
import { AuthService } from 'src/app/services/auth.service';
import { BookService } from 'src/app/services/book.service';
import { BookrentalrequestService } from 'src/app/services/bookrentalrequest.service';
 
@Component({
  selector: 'app-userviewbooks',
  templateUrl: './userviewbooks.component.html',
  styleUrls: ['./userviewbooks.component.css']
})
export class UserviewbooksComponent implements OnInit {
  successMsg: boolean = false;
  validationMsg: boolean = false;
  searchTerm: string = '';
  books: Book[] = [];
  form: FormGroup;
  bId: number;
  uId: number;
  req: any[] = [];
  exists: boolean = false;
  showForm = false;
 
  // Variable to store the selected image URL for the modal
  selectedImageUrl: string = '';
  showModal: boolean = false;
  selectedBookId: number;
 
  constructor(private service: BookService,private aService: AuthService,private Rservice: BookrentalrequestService,private builder: FormBuilder,private route:Router,private authService:AuthService) { 
  }
 
  ngOnInit(): void {
    this.getBooks();
  }
 
  getBooks() {
    this.service.getAllBooks().subscribe((data: Book[]) => {
      this.books = data;
    });
  }
 
  filteredBooks() {
    return this.books.filter(book =>
      book.title.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      book.author.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      book.genre.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }
 
  rentBook(bookId:any) {
    this.showForm = true;
    this.selectedBookId = bookId;
    this.service.addBook(bookId).subscribe(data=>{
      this.books=data;
    })
    // Logic to rent the book (e.g., navigate to a rental form)
    console.log('Navigate to Book Rental Request Form for:', bookId);
  }
 
  showCoverImage(imagePath: string) {
    this.selectedImageUrl = imagePath;
    this.showModal = true;
  }
 
  closeModal() {
    this.showModal = false;
  }

  logout(): void {
    this.authService.logout();
    this.route.navigate(['/api/login']);
  }
 
  confirmLogout(): void {
    this.showLogoutConfirm = true;
  }
 
  cancelLogout(): void {
    this.showLogoutConfirm = false;
  }
 
  performLogout(): void {
    this.showLogoutConfirm = false;
    this.logout();
  }
 
  showLogoutConfirm = false;
 

  
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Feedback } from 'src/app/models/feedback.model';
import { AuthService } from 'src/app/services/auth.service';
import { FeedbackService } from 'src/app/services/feedback.service';

@Component({
  selector: 'app-adminviewfeedback',
  templateUrl: './adminviewfeedback.component.html',
  styleUrls: ['./adminviewfeedback.component.css']
})
export class AdminviewfeedbackComponent implements OnInit {
  userId = 0;
  feedbacks:Feedback [] = [] ;
  selectedUser: any = null;
  
  constructor(private service: FeedbackService,private ar:ActivatedRoute,private route:Router,private authService:AuthService ) { }

  getFeedbacks() {
    this.service.getFeedbacks().subscribe(data => {
      this.feedbacks = data;
    }, error => {
      console.error('Error fetching feedbacks', error);
    });
  }
  showProfile(user: any): void {
    this.selectedUser = user;
    
  }

  closeProfile(): void {
    this.selectedUser = null;
  }


  ngOnInit(): void {
    this.getFeedbacks();
  }

  

  logout(): void {
    this.authService.logout();
    this.route.navigate(['/api/login']);
  }
 
  confirmLogout(): void {
    this.showLogoutConfirm = true;
  }
 
  cancelLogout(): void {
    this.showLogoutConfirm = false;
  }
 
  performLogout(): void {
    this.showLogoutConfirm = false;
    this.logout();
  }
 
  showLogoutConfirm = false;
 
}

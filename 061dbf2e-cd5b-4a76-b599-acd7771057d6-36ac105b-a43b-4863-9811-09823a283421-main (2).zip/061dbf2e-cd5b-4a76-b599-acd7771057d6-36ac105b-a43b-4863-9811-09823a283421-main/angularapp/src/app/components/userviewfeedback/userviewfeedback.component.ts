import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Feedback } from 'src/app/models/feedback.model';
import { AuthService } from 'src/app/services/auth.service';
import { FeedbackService } from 'src/app/services/feedback.service';

@Component({
  selector: 'app-userviewfeedback',
  templateUrl: './userviewfeedback.component.html',
  styleUrls: ['./userviewfeedback.component.css']
})
export class UserviewfeedbackComponent implements OnInit {

  feedbacks: Feedback[] = [];
  feedback:Feedback;
  userId: number = 1; 
  feedbackId: number = 0;
  constructor(private feedbackService:FeedbackService,private authService:AuthService,private router:Router) { }

  ngOnInit(): void {
    this.getFeedbacks();
  }

  getFeedbacks() {
    this.feedbackService.getFeedbacks().subscribe(data => {
      this.feedbacks = data;
    }, error => {
      console.error('Error fetching feedbacks', error);
    });
  }

  getAllFeedbacksByUserId(userId:number) {
    this.feedbackService.getAllFeedbacksByUserId(userId).subscribe(data => {
      this.feedbacks = data;
    }, error => {
      console.error('Error fetching feedbacks by user ID', error);
    });
  }
  
  deleteFeedback(feedBackId:number) {
    this.feedbackService.deleteFeedback(feedBackId).subscribe(data => {
      console.log('Feedback Deleted', data);
      this.getFeedbacks(); 
    }, error => {
      console.error('Error deleting feedback', error);
    });
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/api/login']);
  }
 
  confirmLogout(): void {
    this.showLogoutConfirm = true;
  }
 
  cancelLogout(): void {
    this.showLogoutConfirm = false;
  }
 
  performLogout(): void {
    this.showLogoutConfirm = false;
    this.logout();
  }
  showLogoutConfirm = false;


}


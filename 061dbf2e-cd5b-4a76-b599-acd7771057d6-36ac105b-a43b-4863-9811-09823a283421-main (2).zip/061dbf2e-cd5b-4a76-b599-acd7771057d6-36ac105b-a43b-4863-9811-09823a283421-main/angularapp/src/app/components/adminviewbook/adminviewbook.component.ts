import { Component, OnInit, Input } from '@angular/core';
import { BookService } from 'src/app/services/book.service';
import { Book } from 'src/app/models/book.model';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';
 
@Component({
  selector: 'app-adminviewbook',
  templateUrl: './adminviewbook.component.html',
  styleUrls: ['./adminviewbook.component.css']
})
export class AdminviewbookComponent implements OnInit {
 
  book: Book = {
    title: "",
    author: "",
    genre: "",
    description: "",
    rentalFee: 0,
    isAvailable: true,
    coverImage: ""
 
 
  };
 
  books: Book[] = [];
  bookId: number;
  selectedImageUrl: string = ''; 
  selectedImage:string='';
  showModal: boolean = false;
  isPopupVisible:boolean=false;
  displayedCoverImage:string | null = null;
 
  isEditMode = false;
  selectedBook: Book = {} as Book;
  editIndex: number = -1;
 
  constructor(private service: BookService,private route:Router,private authService:AuthService) { }
 
  ngOnInit(): void {
    this.getBooks();
  }
 
  getBooks() {
    this.service.getAllBooks().subscribe((data: Book[]) => {
      this.books = data;
    });
  }
 
  showDetails(request: any): void {
  }
 
  editBook(index: number) {
    this.editIndex = index;
    this.selectedBook = { ...this.books[index] };
    this.isEditMode = true;
  }
 
  cancelEdit() {
    this.selectedBook = {} as Book;
    this.editIndex = -1;
    this.isEditMode = false;
  }

  updateBook() { 
    if (this.editIndex >= 0) { 
    this.service.updateBook(this.selectedBook.bookId, this.selectedBook).subscribe((updatedBook) => { 
      this.books[this.editIndex] = updatedBook; 
      // alert('Book updated successfully!'); 
      this.cancelEdit(); }); 
    } 
  }
 
  deleteBook(index: number) {
    const bookId = this.books[index].bookId;
    this.service.deleteBook(bookId).subscribe(() => {
      this.books.splice(index, 1);
      // alert('Book deleted successfully!');
    });
  }
 
  onBookAdded(book: Book) {
    this.books.push(book);
  }
 
  toggleStatus(index: number) {
    const book = this.books[index];
    const newStatus = !book.isAvailable; 
    this.service.updateBook(book.bookId, { ...book, isAvailable: newStatus }).subscribe((updatedBook) => { 
      this.books[index].isAvailable = updatedBook.isAvailable; 
      // alert(`Book status updated to ${updatedBook.isAvailable ? 'Available' : 'Unavailable'}`); 
    }); 
  }

  logout(): void {
    this.authService.logout();
    this.route.navigate(['/api/login']);
  }
 
  confirmLogout(): void {
    this.showLogoutConfirm = true;
  }
 
  cancelLogout(): void {
    this.showLogoutConfirm = false;
  }
 
  performLogout(): void {
    this.showLogoutConfirm = false;
    this.logout();
  }
  showLogoutConfirm = false;

  showCoverImage(imageUrl: string)
  { this.selectedImageUrl = imageUrl;
    this.showModal = true;
  }
 
  closeModal()
  {
    this.showModal = false;
  }
  closeCoverImage() {
    this.displayedCoverImage = null;
  }
 
showImagePopUp(image:string){
    this.selectedImage=image;
    this.isPopupVisible=true;
  }
  closePopup(){
    this.isPopupVisible=false;
  }
}

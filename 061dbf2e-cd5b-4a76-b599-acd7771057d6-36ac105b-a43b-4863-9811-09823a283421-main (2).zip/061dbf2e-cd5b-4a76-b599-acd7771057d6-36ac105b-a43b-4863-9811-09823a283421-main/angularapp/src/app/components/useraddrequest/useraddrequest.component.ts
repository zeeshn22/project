// import { Component, OnInit } from '@angular/core';
// import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { ActivatedRoute, Router } from '@angular/router';
// import { BookRentalRequest } from 'src/app/models/book-rental-request.model';
// import { AuthService } from 'src/app/services/auth.service';
// import { BookrentalrequestService } from 'src/app/services/bookrentalrequest.service';

// @Component({
//   selector: 'app-useraddrequest',
//   templateUrl: './useraddrequest.component.html',
//   styleUrls: ['./useraddrequest.component.css']
// })
// export class UseraddrequestComponent implements OnInit {
//   successMsg: boolean = false;
//   validationMsg: boolean = false;

  
//   form: FormGroup;
//   bId: number;
//   uId: number;
//   req: any[] = [];
//   exists: boolean = false;
 
//   constructor(private service: BookrentalrequestService, private builder: FormBuilder, private ar: ActivatedRoute, private router: Router, private aService: AuthService,private route:Router,private authService:AuthService) {
 
//     this.form = builder.group({
//       returnDate: ['', [Validators.required,this.validateDate]],
//       comments: ['',[Validators.required]]
//     })  
//   }
 
//   ngOnInit(): void {
//     this.bId = this.ar.snapshot.params['id'];
//      console.log('Book ID from route:', this.bId);
 
//   }
 
//   goBack() {
//     this.router.navigate(['/userViewBook']);
//   }
 
 
//   addRequest() {
//     this.uId = this.aService.getAuthenticatedUserId()

//     console.log('Id...........'+this.uId);
//     console.log('Id...........'+this.bId);
//      const today = new Date();
//      const formattedDate = today.toISOString().split('T')[0];
//     if(this.form.valid){
     
     
//         let ob: BookRentalRequest = {
//           id: this.uId,
//           bookId: this.bId,
//           requestDate: formattedDate,
//           returnDate: this.form.value.returnDate,
//           status: 'Pending',
//           comments: this.form.value.comments,
//           reason:''
//         }
//         console.log(JSON.stringify(ob));
//         this.service.addBookRentalRequest(ob).subscribe(x => {
//           // Success SweetAlert2 Swal.fire({ icon: 'success', title: 'Request Submitted!', text: 'Your book rental request has been successfully submitted. Get ready to dive into your next adventure!', showClass: { popup: 'animated tada' }, hideClass: { popup: 'animated fadeOut' }, background: '#d4edda', // Light Green background color: '#155724', // Dark Green text confirmButtonColor: '#28a745', // Green button confirmButtonText: 'Awesome!' }); this.router.navigate(['/api/viewbookrentalrequest']); }, error => { // Error SweetAlert2 Swal.fire({ icon: 'error', title: 'Oops...', text: 'Request for this book already exists! Try exploring other amazing books.', showClass: { popup: 'animated shake' }, hideClass: { popup: 'animated fadeOut' }, background: '#f8d7da', // Light Red background color: '#721c24', // Dark Red text confirmButtonColor: '#dc3545', // Red button confirmButtonText: 'Got it!'
//           this.router.navigate(['/api/viewbookrentalrequest']);
//         }
//         , (error) => {
//           console.log('from ATHARVA' + error);
//           // alert("Request for this book already exists! - from springboot");
//           this.router.navigate(['/api/books']);
//         }
//         );
       
     
     
//     }
//   } 
//   validateDate(control:AbstractControl){
//     let requestDate=new Date();
//     let retunDate=new Date(control.value);
//     console.log('request Date.........'+requestDate);
//     console.log('return Date.........'+retunDate);
//     if(requestDate>retunDate){
//       return {invaliddate:true};
//     }

//     let retunDate07=new Date(requestDate);
//     retunDate07.setDate(requestDate.getDate()+7);
//     console.log('returnDate07........ '+retunDate07)
//     if(retunDate<retunDate07){
//       return {dateMismatch:true};
//     }
//     return null;
//   }

//   logout(): void {
//     this.authService.logout();
//     this.route.navigate(['/api/login']);
//   }
 
//   confirmLogout(): void {
//     this.showLogoutConfirm = true;
//   }
 
//   cancelLogout(): void {
//     this.showLogoutConfirm = false;
//   }
 
//   performLogout(): void {
//     this.showLogoutConfirm = false;
//     this.logout();
//   }
 
//   showLogoutConfirm = false;
// }

import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BookRentalRequest } from 'src/app/models/book-rental-request.model';
import { AuthService } from 'src/app/services/auth.service';
import { BookrentalrequestService } from 'src/app/services/bookrentalrequest.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-useraddrequest',
  templateUrl: './useraddrequest.component.html',
  styleUrls: ['./useraddrequest.component.css']
})
export class UseraddrequestComponent implements OnInit {
  successMsg: boolean = false;
  validationMsg: boolean = false;

  form: FormGroup;
  bId: number;
  uId: number;
  req: any[] = [];
  exists: boolean = false;

  constructor(
    private service: BookrentalrequestService,
    private builder: FormBuilder,
    private ar: ActivatedRoute,
    private router: Router,
    private aService: AuthService,
    private route: Router,
    private authService: AuthService
  ) {
    this.form = builder.group({
      returnDate: ['', [Validators.required, this.validateDate]],
      comments: ['', [Validators.required]]
    });
  }

  ngOnInit(): void {
    this.bId = this.ar.snapshot.params['id'];
    console.log('Book ID from route:', this.bId);
  }

  goBack() {
    this.router.navigate(['/userViewBook']);
  }

  addRequest() {
    this.uId = this.aService.getAuthenticatedUserId();

    console.log('Id...........' + this.uId);
    console.log('Id...........' + this.bId);
    const today = new Date();
    const formattedDate = today.toISOString().split('T')[0];
    if (this.form.valid) {
      let ob: BookRentalRequest = {
        id: this.uId,
        bookId: this.bId,
        requestDate: formattedDate,
        returnDate: this.form.value.returnDate,
        status: 'Pending',
        comments: this.form.value.comments,
        reason: ''
      };
      console.log(JSON.stringify(ob));
      this.service.addBookRentalRequest(ob).subscribe(
        x => {
          // Success SweetAlert2
          Swal.fire({
            icon: 'success',
            title: 'Request Submitted!',
            text: 'Your book rental request has been successfully submitted. Get ready to dive into your next adventure!',
            showClass: {
              popup: 'animated tada'
            },
            hideClass: {
              popup: 'animated fadeOut'
            },
            background: '#d4edda',  // Light Green background
            color: '#155724',  // Dark Green text
            confirmButtonColor: '#28a745',  // Green button
            confirmButtonText: 'Awesome!'
          });
          this.router.navigate(['/api/viewbookrentalrequest']);
        },
        error => {
          // Error SweetAlert2
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Request for this book already exists! Try exploring other amazing books.',
            showClass: {
              popup: 'animated shake'
            },
            hideClass: {
              popup: 'animated fadeOut'
            },
            background: '#f8d7da',  // Light Red background
            color: '#721c24',  // Dark Red text
            confirmButtonColor: '#dc3545',  // Red button
            confirmButtonText: 'Got it!'
          });
          this.router.navigate(['/api/viewbooks']);
        }
      );
    }
  }

  validateDate(control: AbstractControl) {
    let requestDate = new Date();
    let returnDate = new Date(control.value);
    console.log('request Date.........' + requestDate);
    console.log('return Date.........' + returnDate);
    if (requestDate > returnDate) {
      return { invaliddate: true };
    }

    let returnDate07 = new Date(requestDate);
    returnDate07.setDate(requestDate.getDate() + 7);
    console.log('returnDate07........ ' + returnDate07)
    if (returnDate < returnDate07) {
      return { dateMismatch: true };
    }
    return null;
  }

  logout(): void {
    this.authService.logout();
    this.route.navigate(['/api/login']);
  }

  confirmLogout(): void {
    this.showLogoutConfirm = true;
  }

  cancelLogout(): void {
    this.showLogoutConfirm = false;
  }

  performLogout(): void {
    this.showLogoutConfirm = false;
    this.logout();
  }

  showLogoutConfirm = false;
}

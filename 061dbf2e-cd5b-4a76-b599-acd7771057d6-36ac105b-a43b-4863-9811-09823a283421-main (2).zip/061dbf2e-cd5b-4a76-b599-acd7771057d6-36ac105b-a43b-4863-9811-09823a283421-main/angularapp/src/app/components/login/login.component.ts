import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup; 
  errorMessage: string = ''; // Error message for form validation
  notificationMessage: string = ''; // Notification message text
  notificationType: string = ''; // Notification type: 'success' or 'error'
  loading: boolean = false;

  constructor(private fb: FormBuilder, private rt: Router, private authService: AuthService ) {}

  ngOnInit(): void {
    // Initialize the form group with validation rules
    this.loginForm = this.fb.group({
      username: ['', Validators.required], // Username is required
      password: ['', Validators.required], // Password is required
    });
  }

  public get loginfun() {
    return this.loginForm.controls;
  }

  loginUser() {
    if (this.loginForm.valid) {
      this.loading = true; // Show the loader
      const credentials = this.loginForm.value;
      this.authService.executeAuthencationService(credentials.username, credentials.password).subscribe((data) => {
        this.loading = false; // Hide the loader

        Swal.fire({
          title: 'Welcome Back!',
          text: 'Login successful! Let’s explore the world of books.',
          icon: 'success',
          confirmButtonColor: '#E1A140', // Gold from Autumn Crush palette
          background: '#EFCFA0', // Sand Dollar from Autumn Crush palette
          color: '#532200', // Puce for text
          customClass: {
            popup: 'animated fadeInDown' // Animation for success alert
          }
        });
        console.log("Logged in -> " + data.id);
        if (data.userRole === 'USER') {
           this.rt.navigate(["/user"]);
          }else if (data.userRole === 'ADMIN') {
             this.rt.navigate(["/admin"]); 
          }
      }, error => {
        this.loading = false; // Hide the loader on error

        Swal.fire({
          title: 'Oops!',
          text: 'Incorrect details. Please double-check and try again.',
          icon: 'error',
          confirmButtonColor: '#914110', // Burnt Orange from Autumn Crush palette
          background: '#EFCFA0', // Sand Dollar from Autumn Crush palette
          color: '#532200', // Puce for text
          customClass: {
            popup: 'animated shake' // Animation for error alert
          }
        });
        console.error("Login failed");
      });
    }
  }



}

  







  



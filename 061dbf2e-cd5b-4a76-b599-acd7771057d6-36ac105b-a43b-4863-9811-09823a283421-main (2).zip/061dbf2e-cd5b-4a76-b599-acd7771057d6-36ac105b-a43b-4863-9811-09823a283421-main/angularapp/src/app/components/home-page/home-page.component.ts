import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {
  quotes: { text: string, author: string }[] = [
    { text: "A room without books is like a body without a soul.", author: "Marcus Tullius Cicero" },
    { text: "So many books, so little time.", author: "Frank Zappa" },
    { text: "A book is a dream that you hold in your hand.", author: "Neil Gaiman" },
    { text: "Books are a uniquely portable magic.", author: "Stephen King" },
    { text: "There is no friend as loyal as a book.", author: "Ernest Hemingway" }
  ];
  currentQuote: { text: string, author: string } = this.quotes[0];
  quoteIndex: number = 0;
  user = { username: '', role: '' };
  showLogoutConfirm = false;


  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    this.startQuoteRotation();
  }

  startQuoteRotation(): void {
    setInterval(() => {
      this.quoteIndex = (this.quoteIndex + 1) % this.quotes.length;
      this.currentQuote = this.quotes[this.quoteIndex];
    }, 3000); // Change quote every 3 seconds
  }


  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
 
  confirmLogout(): void {
    this.showLogoutConfirm = true;
  }
  cancelLogout(): void {
    this.showLogoutConfirm = false;
  }
  performLogout(): void {
    this.showLogoutConfirm = false; this.logout();
  }
}
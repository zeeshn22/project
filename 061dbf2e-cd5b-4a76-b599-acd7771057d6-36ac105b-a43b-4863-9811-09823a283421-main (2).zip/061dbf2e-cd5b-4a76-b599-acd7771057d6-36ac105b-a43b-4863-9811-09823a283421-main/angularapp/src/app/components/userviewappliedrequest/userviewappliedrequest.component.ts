import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookRentalRequest } from 'src/app/models/book-rental-request.model';
import { AuthService } from 'src/app/services/auth.service';
import { BookrentalrequestService } from 'src/app/services/bookrentalrequest.service';

@Component({
  selector: 'app-userviewappliedrequest',
  templateUrl: './userviewappliedrequest.component.html',
  styleUrls: ['./userviewappliedrequest.component.css']
})
export class UserViewAppliedRequestComponent implements OnInit {

  searchTitle:string="";
  request:BookRentalRequest;
  setRequest:BookRentalRequest;
  view:boolean=false;
  requests:any[];
  uId: number;
 
 
  constructor(private service:BookrentalrequestService,private aService: AuthService,private route:Router,private authService:AuthService) { }
 
  ngOnInit(): void {
    this.getAllRequest();
   
  }
 
  getAllRequest(){
    this.uId = this.aService.getAuthenticatedUserId()
    this.service.getAllBookRentalRequests().subscribe(x=>{
      this.requests=x;
      console.log(x)
      this.requests=this.requests.filter(x=>x.user.userId==this.uId);
 
    })
    console.log(this.uId)
  }
 
 
  showMore(id:number){
    this.view=!this.view;
    this.service.getBookRentalRequestById(id).subscribe(x=>{
      this.request=x;
    })
  }
 
  deleteRequest(id:number){
    this.service.deleteBookRentalRequest(id).subscribe(x=>{
      this.getAllRequest();
    });
  }
  logout(): void {
    this.authService.logout();
    this.route.navigate(['/api/login']);
  }
 
  confirmLogout(): void {
    this.showLogoutConfirm = true;
  }
 
  cancelLogout(): void {
    this.showLogoutConfirm = false;
  }
 
  performLogout(): void {
    this.showLogoutConfirm = false;
    this.logout();
  }
 
  showLogoutConfirm = false;
}


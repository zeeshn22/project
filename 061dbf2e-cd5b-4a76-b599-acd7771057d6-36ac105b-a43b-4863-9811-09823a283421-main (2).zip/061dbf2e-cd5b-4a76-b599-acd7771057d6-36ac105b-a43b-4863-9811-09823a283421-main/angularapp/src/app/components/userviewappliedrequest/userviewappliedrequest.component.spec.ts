import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserViewAppliedRequestComponent } from './userviewappliedrequest.component';

describe('UserviewappliedrequestComponent', () => {
  let component: UserViewAppliedRequestComponent;
  let fixture: ComponentFixture<UserViewAppliedRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserViewAppliedRequestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserViewAppliedRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

// import { Component, Input, OnInit } from '@angular/core';
// import { ActivatedRoute, Router } from '@angular/router';
// import { AuthService } from 'src/app/services/auth.service';
 
// @Component({
//   selector: 'app-usernav',
//   templateUrl: './usernav.component.html',
//   styleUrls: ['./usernav.component.css']
// })
// export class UsernavComponent implements OnInit {
//   user = { username: '', role: '' };
//   showLogoutConfirm = false;
//   userId = 0;
 
//   constructor(private authService:AuthService, private router:Router, private ar: ActivatedRoute){}
 
//   ngOnInit(): void {
//     this.userId = this.ar.snapshot.params['id'];
//   }
 
//   logout(): void {
//     this.authService.logout();
//     this.router.navigate(['/api/login']);
//   }
 
//   confirmLogout(): void {
//     this.showLogoutConfirm = true;
//   }
//   cancelLogout(): void {
//     this.showLogoutConfirm = false;
//   }
//   performLogout(): void {
//     this.showLogoutConfirm = false; this.logout();
//   }
 
// }

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
 
@Component({
  selector: 'app-usernav',
  templateUrl: './usernav.component.html',
  styleUrls: ['./usernav.component.css']
})
export class UsernavComponent implements OnInit {
  user = { username: '', role: '' };
  showLogoutConfirm = false;
  userId = 0;
  quotes: { text: string, author: string }[] = [
    { text: "A room without books is like a body without a soul.", author: "Marcus Tullius Cicero" },
    { text: "So many books, so little time.", author: "Frank Zappa" },
    { text: "A book is a dream that you hold in your hand.", author: "Neil Gaiman" },
    { text: "Books are a uniquely portable magic.", author: "Stephen King" },
    { text: "There is no friend as loyal as a book.", author: "Ernest Hemingway" }
  ];
  currentQuote: { text: string, author: string } = this.quotes[0];
  quoteIndex: number = 0;
 
  constructor(private authService: AuthService, private router: Router, private ar: ActivatedRoute) {}
 
 
 
  startQuoteRotation(): void {
    setInterval(() => {
      this.quoteIndex = (this.quoteIndex + 1) % this.quotes.length;
      this.currentQuote = this.quotes[this.quoteIndex];
    }, 3000); // Change quote every 3 seconds
  }
 
  typeText(): void {
    const title = 'Welcome to BookHeaven';
    const subtitle = 'Discover your next adventure among 1,000,000+ books across 467 categories. Trusted by Google, Amazon, Microsoft, and more!';
    let titleIndex = 0;
    let subtitleIndex = 0;
 
    const titleElement = document.querySelector('.dynamic-title');
    const subtitleElement = document.querySelector('.dynamic-subtitle');
 
    function typeTitle() {
      if (titleIndex < title.length) {
        if (titleElement) {
          titleElement.textContent += title.charAt(titleIndex);
        }
        titleIndex++;
        setTimeout(typeTitle, 100);
      } else {
        typeSubtitle();
      }
    }
 
    function typeSubtitle() {
      if (subtitleIndex < subtitle.length) {
        if (subtitleElement) {
          subtitleElement.textContent += subtitle.charAt(subtitleIndex);
        }
        subtitleIndex++;
        setTimeout(typeSubtitle, 100);
      }
    }
 
    typeTitle();
  }
 
  ensureVideoPlays(): void {
    const videoElement = document.querySelector('.background-video') as HTMLVideoElement;
    if (videoElement) {
      const playVideo = () => {
        videoElement.play().catch(error => {
          console.error('Error attempting to play video:', error);
        });
      };
 
      playVideo(); // Play video on load
 
      videoElement.addEventListener('ended', playVideo); // Replay when ended
      videoElement.addEventListener('pause', playVideo); // Resume if paused
 
      // Play video on document click
      document.addEventListener('click', playVideo);
 
      // Optional: Ensure video plays when the page becomes visible again
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') {
          playVideo();
        }
      });
    }
  }
 
 
  ngOnInit(): void {
    this.userId = this.ar.snapshot.params['id'];
    this.startQuoteRotation();
    this.typeText();
    this.ensureVideoPlays();
  }
 
  logout(): void {
    this.authService.logout();
    this.router.navigate(['/api/login']);
  }
 
  confirmLogout(): void {
    this.showLogoutConfirm = true;
  }
 
  cancelLogout(): void {
    this.showLogoutConfirm = false;
  }
 
  performLogout(): void {
    this.showLogoutConfirm = false;
    this.logout();
  }
 
}

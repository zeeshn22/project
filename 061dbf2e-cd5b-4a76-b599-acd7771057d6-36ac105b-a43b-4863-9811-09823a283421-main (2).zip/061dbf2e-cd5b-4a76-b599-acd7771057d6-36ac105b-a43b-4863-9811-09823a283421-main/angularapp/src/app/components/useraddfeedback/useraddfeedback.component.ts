import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { AuthService } from 'src/app/services/auth.service';
 
import { FeedbackService } from 'src/app/services/feedback.service';
import Swal from 'sweetalert2';
 
@Component({
  selector: 'app-useraddfeedback',
  templateUrl: './useraddfeedback.component.html',
  styleUrls: ['./useraddfeedback.component.css']
})
export class UserAddFeedbackComponent {
  feedbackForm: FormGroup;
  feedbackSubmitted: boolean = false;
 
  constructor(private fb: FormBuilder, private feedbackService: FeedbackService, private authService: AuthService,private router:Router) {
    this.feedbackForm = this.fb.group({
      feedbackText: ['', Validators.required]
    });
  }


 
  onSubmit(): void {
    if (this.feedbackForm.valid) {
      const feedbackData = {
        ...this.feedbackForm.value,
        date: new Date() // Add the current date here
      };
      this.feedbackService.sendFeedback(feedbackData).subscribe(() => {
        this.feedbackSubmitted = true;
        // alert('Successfully Added!');
        this.router.navigate(["/api/feedback"]);
        Swal.fire({
          title: 'Success!',
          text: 'Feedback submitted successfully!',
          icon: 'success',
          confirmButtonColor: '#E1A140', // Gold from Autumn Crush palette
          background: '#EFCFA0', // Sand Dollar from Autumn Crush palette
          color: '#532200', // Puce for text
          customClass: {
            popup: 'animated fadeInDown' // Animation for success alert
          }
        });
        this.feedbackForm.reset();
      }, error => {
        console.error('Error submitting feedback:', error);
        // alert('Failed to submit feedback. Please try again.');
      });
    }
  }
 
  get f() {
    return this.feedbackForm.controls;
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/api/login']);
  }

  confirmLogout(): void {
    this.showLogoutConfirm = true;
  }

  cancelLogout(): void {
    this.showLogoutConfirm = false;
  }

  performLogout(): void {
    this.showLogoutConfirm = false;
    this.logout();
  }

  showLogoutConfirm = false;
}


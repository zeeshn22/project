export interface BookRentalRequest{
    rentalId?:number;
    id?:number,
    bookId?:number,
    requestDate:string;
    returnDate:string;
    status:string;
    comments:string;
    reason:string;
   
}

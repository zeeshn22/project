export interface User{
    id?:number;
    email?:string;
    password?:string;
    username?:string;
    mobileNumber?:string;
    userRole?:string;

}


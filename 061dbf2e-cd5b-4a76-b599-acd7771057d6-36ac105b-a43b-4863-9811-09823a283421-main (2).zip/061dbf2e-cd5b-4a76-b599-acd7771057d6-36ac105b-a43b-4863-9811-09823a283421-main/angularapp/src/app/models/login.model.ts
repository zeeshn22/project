export class Login{
    password:string;
    email:string;
    userRole:string;
}

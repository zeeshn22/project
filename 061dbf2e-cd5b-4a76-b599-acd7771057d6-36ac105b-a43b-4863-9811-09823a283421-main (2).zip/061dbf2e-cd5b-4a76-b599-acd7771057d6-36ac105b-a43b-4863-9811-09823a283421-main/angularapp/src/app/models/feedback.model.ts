
export interface Feedback{
    feedbackId?:number;
    id:number;
    feedbackText:string;
    date:Date;

}
